package UTS;

public interface Koperasi {
    public int LoanMonthly(int loan);
}
