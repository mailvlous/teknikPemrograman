public class App {
    public static void main(String[] args) {
        Presiden Jokowi = new Presiden("Jokowi", "Presiden");
        Jokowi.bekerja();
        Jokowi.melayaniMasyarakat();
        Jokowi.buatKebijakan();
        Jokowi.evaluasiKebijakan();
    }
}
