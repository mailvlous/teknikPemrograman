public interface PembuatKebijakan {
    void buatKebijakan();
    void evaluasiKebijakan();
}
