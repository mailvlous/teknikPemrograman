public interface PenegakHukum {
    void menegakkanHukum();
    void menjatuhkanSanksi();
}
