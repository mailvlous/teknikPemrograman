package Week8;

public interface Content {
    void display();
}
