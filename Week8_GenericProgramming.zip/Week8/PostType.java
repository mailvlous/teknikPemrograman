

public enum PostType {
    TEXT,
    IMAGE,
    POLL,
    VIDEO
}
